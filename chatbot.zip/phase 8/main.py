from flask import Flask, render_template, request
from chat import response
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process',methods=['POST'])


def process():
    user_input=request.form['user_input']
    #print("Friend: "+str(response(user_input)))
    return render_template('index.html',user_input=user_input,
        bot_response=str(response(user_input))
        )
if __name__=='__main__':
	app.run(debug=True,port=5002)